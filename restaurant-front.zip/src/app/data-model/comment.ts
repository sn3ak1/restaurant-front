export interface Comment {
  _id: string;
  rating: number;
  comment?: string;
}
